-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2021 at 09:35 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drinkkiarkisto`
--

-- --------------------------------------------------------

--
-- Table structure for table `resepti`
--

CREATE TABLE `resepti` (
  `Resepti_id` int(11) NOT NULL,
  `Nimi` varchar(50) NOT NULL,
  `Juomalaji` varchar(50) NOT NULL,
  `Ainesosat` varchar(100) NOT NULL,
  `Valmistusohje` text NOT NULL,
  `Kayttaja_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `resepti`
--

INSERT INTO `resepti` (`Resepti_id`, `Nimi`, `Juomalaji`, `Ainesosat`, `Valmistusohje`, `Kayttaja_id`) VALUES
(2825, 'vesi', 'vesi', 'lisää vettä', 'Avaa hana ja ota vettä', 0),
(6762, 'vesi', 'vesi', 'lisää vettä', 'Avaa hana ja ota vettä', 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
