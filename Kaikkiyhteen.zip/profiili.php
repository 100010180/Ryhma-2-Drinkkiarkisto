<?php
	include	"tietokanta.php";
	include "todentaminen.php";
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css.css">
	<title>Profiili</title>
	<style type="text/css">
	body {
		background-image: url("tausta.jpg");
	}
		.wrapper {
			margin-top: 150px; 
			width: 500px;
			margin-left: auto;
			margin-right: auto;
			color: white;
		}

		table, tr{
			margin-left: auto;
			margin-right: auto;
			border: solid 3px black;
		}
		td {
			border: solid black 1px;
		}
		
		h1 {
			display: inline-block;
			text-align: center;
			font-size: 50px;
			width: 100%;
		}
		
		/*		NAVIGOINTIPALKKI		*/

		nav {
  			mask-image: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, #ffffff 25%, #ffffff 75%, rgba(255, 255, 255, 0) 100%);
  			margin: 0 auto;
  			width: auto;
  			text-align: center;
  			margin-top: 10px;
		}

		nav ul {
  			background: linear-gradient(90deg, rgba(255, 255, 255, 0) 0%, rgba(255, 255, 255, 0.2) 15%, rgba(255, 255, 255, 0.2) 85%, rgba(255, 255, 255, 0) 100%);
  			box-shadow: 0 0 25px rgba(0, 0, 0, 0.1), inset 0 0 1px rgba(255, 255, 255, 0.6);

		}

		nav ul li {
  			display: inline-block; 
		}

		nav ul li a {
  			padding: 16px;
  			font-family: "Open Sans";
  			text-transform: uppercase;
  			color: rgba(0, 35, 122, 0.5);
  			font-size: 20px;
  			text-decoration: none;
  			display: block;
		}

		nav ul li a:hover {
  			box-shadow: 0 0 10px rgba(0, 0, 0, 0.1), inset 0 0 1px rgba(255, 255, 255, 0.6);
  			background: rgba(255, 255, 255, 0.1);
  			color: rgba(0, 35, 122, 0.7);
		}

	</style>
</head>
<body>
<h1>Drinkkiarkisto</h1>

<nav class="sub">
  <ul>
  <li><a href="profiili.php">Profiili</a></li>  
  <li><a href="etusivu.php">Etusivu</a></li>
  <li><a href="lista_resepteista.php">Reseptit</a></li> 
</ul>
</nav>
	<div class="container">
		<form action="edit.php" methot="post">
		<button class="btn btn-default" style="float: right:" name= 
		"submit1" type="submit">Muokkaa</button>
		</form>
		
		<div class="wrapper">
		<?php
		if(isset($_POST['submit1'])) {
			?>
			<script type="text/javascript">
				window.location:"edit.php"
			</script>
			<?php
			
		}


			
			$q=mysqli_query($con, "SELECT * FROM kayttaja WHERE kayttajatunnus='$_SESSION[kayttajatunnus]';");
			
			?>
			<h2 style="text-align: center;">Profiili</h2>
			<?php
			$row=mysqli_fetch_assoc($q);
			?>
			<br>
			<div style="text-align: center; font-size: 20px;"><b>Hei</b>
			<h3>
			<?php
				echo $_SESSION['kayttajatunnus'];
			?>
			</h3>
			</div>

			<?php
				echo "<b>";
				echo "<table class='table table-bordered'>";
				
				echo "<tr>";
					echo "<td>";
						echo "<b> Käyttäjänimi: </b>";
					echo "</td>";

					echo "<td>";
						echo $row['kayttajatunnus'];
					echo "</td>";
				echo "</tr>";

				echo "<tr>";
					echo "<td>";
					echo "<b> Sähköposti: </b>";
					echo "</td>";

					echo "<td>";
						echo $row['sahkoposti'];
					echo "</td>";
				echo "</tr>";

				//echo "<tr>";
				//	echo "<td>";
				//	echo "<b> Salasana: </b>";
				//	echo "</td>";
				//
				//	echo "<td>";
				//		echo $row['password'];
				//	echo "</td>";
				//echo "</tr>";
			// Salasanan näyttäminen mielestäni turhaa...
				echo "</table>";
				echo "</b>";
			?>
		</div>
	</div>
</body>
</html>